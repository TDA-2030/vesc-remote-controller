#ifndef __TYPEDEF_H
#define __TYPEDEF_H


//typedef unsigned char u8;

#endif
